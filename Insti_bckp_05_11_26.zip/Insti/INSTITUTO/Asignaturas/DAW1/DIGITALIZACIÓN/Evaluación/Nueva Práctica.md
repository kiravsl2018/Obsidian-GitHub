---
tags:
  - practica
Asignatura: Digitalización
Tema:
  - 02 - Tecnologías Habilitadoras Digitales
To-Do: Pendiente
Prioridad: Media 🟡
Entrega: 2026-11-16
---
[[DIGITALIZACIÓN]] · [[DAW HOME]]

---
## 📌 ENUNCIADO


## 🛠️ DESARROLLO


## ✅ ENTREGA

- [ ] #practica PROYECTO PRESENTACIÓN DIGITALIZACION
