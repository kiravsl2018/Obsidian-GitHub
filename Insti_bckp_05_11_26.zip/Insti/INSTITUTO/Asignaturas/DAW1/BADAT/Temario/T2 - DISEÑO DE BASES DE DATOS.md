---
tags:
  - temario
Asignatura: Base de Datos
Tema:
  - 02 - Diseño de Bases de Datos
Prioridad: Media 🟡
To-Do: Pendiente
---
[[BADAT]] 

# Aprendamos a Diseñar

> Siempre vamos a partir de un documento con los detalles de lo que quiere la empresa.
> 
> A eso se le llama:
> >**ESPECIFICACIÓN DE REQUISITOS**

En la **ESPECIFICACIÓN DE REQUISITOS** debe existir todas las cosas importantes que necesite una empresa.

Seguidamente, debemos seguir una *metodología*. En nuestro caso vamos a usar la *metodología Métrica*

## METODOLOGÍA MÉTRICA

>[!info] FASE 1 : Diseño Conceptual de datos
>>Objetivo -> Obtener el MODELO CONCEPTUAL DE DATOS
>
>==🟣Pasos ->==
>- Detectar las entidades  -> [[#*DEFINICIÓN DE ENTIDAD*]] 
>- Detectar las relaciones entre entidades -> [[#*DEFINICIÓN DE RELACIÓN*]]
>- Dibujar el diagrama *E/R de Chen* (entidad/relación) [[#DIAGRAMA E/R DE CHEN]]
>- Hacer listado de entidades


#### *DEFINICIÓN DE ENTIDAD*
---
>[!question] ENTIDAD
>Objeto real o abstracto de interés para la empresa del que se almacena información (que contiene datos).

#### *DEFINICIÓN DE RELACIÓN*
---
>[!QUESTION] RELACIÓN
>Asociaciones entre *entidades* que comparten valores comunes.

#### *DEFINICIÓN DE DEPENDENCIA FUNCIONAL*
---
>[!QUESTION] DEPENDENCIA FUNCIONAL
> !PENDIENTE


#### *RELACIONES*
---

>[!info] RELACIÓN 1:1 
>Dado un registro de A está relacionado con un solo registro de B y viceversa

---

>[!info] RELACIÓN 1:N 
>Dado un registro de A está relacionado con muchos registros de B
>Dado un registro de B está relacionado con muchos registros de A


[[RELACIÓN 1N]]



---

>[!info] RELACIÓN M:N
>Dado muchos registros de A están relacionados con muchos registros de B y viceversa



### DIAGRAMA E/R DE CHEN


| DIAGRAMA   | SIGNIFICADO | GRAFO   |
| ---------- | ----------- | ------- |
| RECTÁNGULO | ENTIDADES   |         |
| ROMBOS     | RELACIONES  | CIRCULO |
|            |             |         |


