---
tags:
  - actividad
cssclasses:
  - trabajo
Asignatura: Base de Datos
Tema:
  - "02 - GRAFOS"
Prioridad: Media 🟡
To-Do: Pendiente
Entrega: 
Profesor: "EVA"
Aula: "Bases de Datos"
---
<div class="portada">
<div class="portada-ciclo">CFGS Desarrollo de Aplicaciones Web</div>
<div class="portada-titulo">Relación de Actividades</div>
<div class="portada-modulo">Bases de Datos</div>
<div class="portada-datos">
<p><b>Alumno:</b> Miguel López Contreras</p>
<p><b>Profesor/a:</b> EVA</p>
<p><b>Aula:</b> Bases de Datos</p>
<p><b>Ciclo formativo:</b> 1º DAW · Desarrollo de Aplicaciones Web (CFGS)</p>
<p><b>Fecha de entrega:</b> </p>
<p><b>Curso académico:</b> 2026/27</p>
</div>
</div>

# Índice

```dataviewjs
// Índice automático: se rehace solo con cada # / ## / ### de esta nota. Enlaces [[#apartado]]: Better Export PDF los hace clicables en el PDF.
const ruta = dv.current().file.path;
const titulos = (app.metadataCache.getCache(ruta)?.headings ?? [])
  .filter((h) => h.level <= 3 && h.heading.trim().toLowerCase() !== 'índice');
const caja = dv.el('div', '', { cls: 'indice-auto' });
if (!titulos.length) dv.el('div', '_Escribe un título con `#` y aparecerá aquí._', { container: caja });
for (const h of titulos) dv.el('div', `[[#${h.heading}|${h.heading}]]`, { container: caja, cls: 'indice-n' + h.level });
```

> [!guia]- Índice y paginación (esta ayuda no sale en el PDF)
> - Los apartados son **los de los criterios de corrección**: si cambia uno, cambia también su título abajo.
> - Exporta a PDF con márgenes **Predeterminado** y sin «Incluir nombre del archivo como título» (la portada ya lo lleva): cada página sale numerada **X/Y**.
> - El índice se actualiza solo con cada `#` y `##` que escribas (con Dataview, sin plugins extra). Numera los apartados como en los criterios: `# 1. …`, `## 1.1 …`.

<div class="salto-pagina"></div>

# 1. Actividad 1
Una empresa de alquiler de equipos a clientes nos contrata para diseñar un nuevo SI.
Los alquileres se hacen en las distintas agencias que tiene la empresa.
Las entrevistas con los trabajadores nos han dado las siguientes reglas de gestión:
-  Todo alquiler se realiza por semanas y como mínimo una.
- Cualquier alquiler comporta 1 o varios equipos
- Todo alquiler debe dar lugar a 1 contrato entre la empresa y el cliente.
-  La agencia posee siempre al menos 1 o más equipos de cada referencia.

Alquiler
Equipos
Contrato
Cliente
Agencia

codAlquiler -> codSemana
codAlquiler -> codEquipo
codAlquiler -> codContrato
codContrato -> codCliente
CodAgencia -> codEquipo

[Grafo Resuelto]([[Ejercicio1-Grafos.excalidraw]])

# 2. Actividad 2
Se desea diseñar una BD para gestionar un Centro Comercial organizado por departamentos, que
contenga información sobre los clientes que han comprado algo, los trabajadores, el género que se
oferta y las ventas realizadas. Se han de tener en cuenta las siguientes restricciones:
-  Existen 3 tipos de trabajadores (Gerentes, jefes y vendedores)
-  Cada departamento está gobernado por un gerente.
-  Un determinado producto (que pertenece a un género) sólo se encuentra en un departamento
-  Los jefes y vendedores sólo pueden pertenecer a un departamento.
-  Un gerente tiene a su cargo a un cierto número de jefes y éstos a su vez a un cierto número de vendedores.
-  Una venta la realiza un vendedor a un cliente y debe quedar constancia del artículo vendido. Sólo un artículo por apunte de venta.



# 3. Actividad 3


# 4. Actividad 4


# 5. Actividad 5


# 6. Actividad 6


# 7. Actividad 7


# 8. Actividad 8


# 9. Actividad 9


# 10. Actividad 10


# 11. Actividad 11


# 12. Actividad 12


# 13. Actividad 13


# 14. Actividad 14





