---
tags:
  - actividad
cssclasses:
  - trabajo
Asignatura: Sistemas
Tema:
  - "02 - Arquitectura del PC"
Prioridad: Media 🟡
To-Do: Pendiente
Entrega: 
Profesor: "FRANCIS"
Aula: "Sistemas Informáticos"
---
<div class="portada">
<div class="portada-ciclo">CFGS Desarrollo de Aplicaciones Web</div>
<div class="portada-titulo">Cables - Conexiones</div>
<div class="portada-modulo">Sistemas Informáticos</div>
<div class="portada-datos">
<p><b>Alumno:</b> Miguel López Contreras</p>
<p><b>Profesor/a:</b> FRANCIS</p>
<p><b>Aula:</b> Sistemas Informáticos</p>
<p><b>Ciclo formativo:</b> 1º DAW · Desarrollo de Aplicaciones Web (CFGS)</p>
<p><b>Fecha de entrega:</b> </p>
<p><b>Curso académico:</b> 2026/27</p>
</div>
</div>

# Índice

```dataviewjs
// Índice automático: se rehace solo con cada # / ## / ### de esta nota. Enlaces [[#apartado]]: Better Export PDF los hace clicables en el PDF.
const ruta = dv.current().file.path;
const titulos = (app.metadataCache.getCache(ruta)?.headings ?? [])
  .filter((h) => h.level <= 3 && h.heading.trim().toLowerCase() !== 'índice');
const caja = dv.el('div', '', { cls: 'indice-auto' });
if (!titulos.length) dv.el('div', '_Escribe un título con `#` y aparecerá aquí._', { container: caja });
for (const h of titulos) dv.el('div', `[[#${h.heading}|${h.heading}]]`, { container: caja, cls: 'indice-n' + h.level });
```

> [!guia]- Índice y paginación (esta ayuda no sale en el PDF)
> - Los apartados son **los de los criterios de corrección**: si cambia uno, cambia también su título abajo.
> - Exporta a PDF con márgenes **Predeterminado** y sin «Incluir nombre del archivo como título» (la portada ya lo lleva): cada página sale numerada **X/Y**.
> - El índice se actualiza solo con cada `#` y `##` que escribas (con Dataview, sin plugins extra). Numera los apartados como en los criterios: `# 1. …`, `## 1.1 …`.

<div class="salto-pagina"></div>

# 1. Actividad 1

![[Conectores traseros 1.jpg]]

1. Puertos USB
2. Puerto HDMI
3. Puerto DisplayPort
4. Puerto DVI
5. Puertos USB 3.0
6. Puertos de Sonido
7. Puerto PS/2
8. Puerto audio óptico  S/PDIF
9. Puerto VGA
10. Puerto Sata Externo
11. Puerto Ethernet
# 2. Actividad 2

![[Conectores traseros 2.jpg]]
1. Puerto USB
2. Puerto PS/2
3. Puerto VGA
4. Puerto DVI
5. Puerto Ethernet
6. Puertos USB 3.0
7.  Puertos de Sonido

# 3. Actividad 3

![[Conectores traseros 3.jpg]]
1. Puerto PS/2
2. Puertos USB 3.0
3. Puerto HDMI
4. Puerto VGA
5. Puerto DVI
6. Puerto Ethernet
7. Puertos USB 
8. Puertos de Sonido


# 4. Actividad 4

![[Conectores traseros 4 (Televisión).jpg]]

1. Puertos HDMI
2. Puerto de Control
3. Puerto VGA
4. Puerto USB 
5. Puerto Audio Analógico
6. Puertos de Video y Audio
7. Puerto Antena
# 5. Actividad 5

![[Conectores.jpg]]

1. Cable BNC y su puerto son Puertos BNC hembra
2. Cable HDMI y su puerto son los Puertos HDMI de una placa base/gráfica y del otro lado un monitor, televisor....
3. Cables Jack sus puertos son los Puertos de la placa base destinados al audio y del otro lado a cualquier tipo de dispositivo de audio que contenga estos puertos
4. Cables DisplayPort, su puerto son los Puertos de la placa base y el de una gráfica, monitor, televisor...
5. Cables USB Tipo C, sus puertos suelen ser los moviles, tablets... aunque actualmente tambien hay cabezales conectados a la fuente de energia de una casa que contienen estos adaptadores
6. Cables RCA 3, a la placa base o a dispositivos de audio
7. Cable USB, sus puertos son la placa base o dispositivos que contengan un USB hembra
8. Cables RJ45 y RJ12 para la conexion de Red, Puertos: rosetas
9. Puerto VGA, para los cables VGA
10. Cables de fibra, para la transmision de Red a larga distancia. Puertos de fibra(router, principalmente).
11. Cable VGA, conectado en puerto VGA
12. Cables de Video, conectados a la placa base principalmente




