---
tags:
  - examen
Asignatura: Sistemas
Tema:
  - 02 - Montaje de Equipos
To-Do: Pendiente
Prioridad: Alta 🔴
Fecha: 2026-11-09
Nota:
---
[[SISTEMAS]] · [[DAW HOME]]

---
## 📅 FECHA Y FORMATO

- **Fecha:** 
- **Tipo / duración:** 

## 📚 CONTENIDOS QUE ENTRAN


## ❓ DUDAS A RESOLVER


## ✅ PLAN DE ESTUDIO

- [ ] #examen EXAMEN DE SISTEMAS
