---
tags:
  - examen
Asignatura: Lenguaje
Tema:
  - 02 - CSS
To-Do: Pendiente
Prioridad: Alta 🔴
Fecha: 2026-11-24
Nota:
---
[[LENGUAJE]] · [[DAW HOME]]

---
## 📅 FECHA Y FORMATO

- **Fecha:** 24/11/2026
- **Tipo / duración:** EXAMEN

## 📚 CONTENIDOS QUE ENTRAN

CSS
## ❓ DUDAS A RESOLVER


## ✅ PLAN DE ESTUDIO

- [ ] #examen EXAMEN CSS
