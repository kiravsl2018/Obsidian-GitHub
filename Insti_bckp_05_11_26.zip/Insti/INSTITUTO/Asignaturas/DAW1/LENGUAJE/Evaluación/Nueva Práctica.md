---
tags:
  - practica
Asignatura: Lenguaje
Tema:
  - PROYECTO WEB
To-Do: Pendiente
Prioridad: Media 🟡
Entrega: 2026-11-24
---
[[LENGUAJE]] · [[DAW HOME]]

---
## 📌 ENUNCIADO


## 🛠️ DESARROLLO


## ✅ ENTREGA

- [ ] #practica PROYECTO WEB
