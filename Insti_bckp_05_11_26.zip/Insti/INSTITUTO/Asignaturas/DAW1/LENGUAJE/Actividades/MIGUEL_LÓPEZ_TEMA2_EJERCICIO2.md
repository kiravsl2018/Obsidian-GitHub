---
tags:
  - actividad
cssclasses:
  - trabajo
Asignatura: Lenguaje
Tema:
  - 01 - Los Lenguajes de Datos
Prioridad: Baja 🟢
To-Do: Pendiente
Entrega:
Profesor: JESÚS
Aula: Lenguaje
---
<div class="portada">
<div class="portada-ciclo">CFGS Desarrollo de Aplicaciones Web</div>
<div class="portada-titulo">MIGUEL_LÓPEZ_TEMA2_EJERCICIO2</div>
<div class="portada-modulo">Lenguajes de Marcas y Sistemas de Gestión de Información</div>
<div class="portada-datos">
<p><b>Alumno:</b> Miguel López Contreras</p>
<p><b>Profesor/a:</b> JESÚS</p>
<p><b>Aula:</b> Lenguaje</p>
<p><b>Ciclo formativo:</b> 1º DAW · Desarrollo de Aplicaciones Web (CFGS)</p>
<p><b>Fecha de entrega:</b> </p>
<p><b>Curso académico:</b> 2026/27</p>
</div>
</div>

# Índice

```dataviewjs
// Índice automático: se rehace solo con cada # / ## / ### de esta nota. Enlaces [[#apartado]]: Better Export PDF los hace clicables en el PDF.
const ruta = dv.current().file.path;
const titulos = (app.metadataCache.getCache(ruta)?.headings ?? [])
  .filter((h) => h.level <= 3 && h.heading.trim().toLowerCase() !== 'índice');
const caja = dv.el('div', '', { cls: 'indice-auto' });
if (!titulos.length) dv.el('div', '_Escribe un título con `#` y aparecerá aquí._', { container: caja });
for (const h of titulos) dv.el('div', `[[#${h.heading}|${h.heading}]]`, { container: caja, cls: 'indice-n' + h.level });
```

> [!guia]- Índice y paginación (esta ayuda no sale en el PDF)
> - Los apartados son **los de los criterios de corrección**: si cambia uno, cambia también su título abajo.
> - Exporta a PDF con márgenes **Predeterminado** y sin «Incluir nombre del archivo como título» (la portada ya lo lleva): cada página sale numerada **X/Y**.
> - El índice se actualiza solo con cada `#` y `##` que escribas (con Dataview, sin plugins extra). Numera los apartados como en los criterios: `# 1. …`, `## 1.1 …`.

<div class="salto-pagina"></div>

## 1. Colocación de elementos
*   **En `<head>`:** la línea de `<meta charset>` y el `<title>`.
*   **En `<body>`:** un párrafo con texto y un `<h1>` con su texto.

## 2. Corrección de anidamiento
El código corregido para cerrar bien las etiquetas es:
```html
<p>Recuerda <strong>traer mañana</strong> tu dinero.</p>
```

## 3. Visualización en el navegador
*   En la pestaña del navegador se verá el título: **Agenda**.
*   Dentro de la página (el contenido) se verá: **Mañana: excursión**.
*   ¿Cambiaría algo si el párrafo estuviera dentro de `<head>`? Técnicamente es HTML inválido porque el contenido visible siempre debe ir en el `<body>`. Aunque los navegadores modernos suelen corregirlo automáticamente y mostrarlo en pantalla, es una mala práctica que rompería la estructura del documento.

## 4. Atributos faltantes
```html
<a href="[https://www.w3.org](https://www.w3.org)">Web del W3C</a>
<img src="foto.jpg" alt="Mi foto de perfil">
```

## 5. Fragmento de código
```html
<h2>Contacto y Soporte</h2>
<p>
  Si necesitas ayuda adicional o tienes alguna duda sobre 
  nuestros servicios, no dudes en visitar nuestra 
  <a href="contacto.html">página de contacto</a>.
</p>
```

## 6. Relación de conceptos
*   **Etiqueta de apertura:** `<ul>`
*   **Etiqueta de cierre:** `</h2>`
*   **Atributo:** `target="_blank"`
*   **Etiqueta vacía:** `<img src="f.png">`

## 7. Detalles mal escritos
Falta escribir las etiquetas en minúsculas y poner el valor del atributo entre comillas.
```html
<p>Horario</p>
<a href="[https://www.w3.org](https://www.w3.org)">W3C</a>
```

## 8. Etiquetas en pareja y vacías
*   **En pareja (apertura y cierre):** `<strong>`, `<li>`, `<p>`, `<html>`.
*   **Vacías (sin cierre):** `<br>`, `<img>`.

## 9. Utilidad de `<!DOCTYPE html>`
Esta línea le indica al navegador el tipo de documento y que se está utilizando la versión HTML5.
Sirve para que el navegador renderice la página correctamente siguiendo los estándares modernos, evitando el "modo peculiar" (quirks mode).





