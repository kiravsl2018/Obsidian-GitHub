---
tags:
  - actividad
cssclasses:
  - trabajo
Asignatura: Lenguaje
Tema:
  - 01 - Los Lenguajes de Datos
Prioridad: Baja 🟢
To-Do: Realizado
Entrega:
Profesor: JESÚS
Aula: Lenguaje de Marcas
---
<div class="portada">
<div class="portada-ciclo">CFGS Desarrollo de Aplicaciones Web</div>
<div class="portada-titulo">MIGUEL_LÓPEZ_TEMA1_EJERCICIO2.14</div>
<div class="portada-modulo">Lenguajes de Marcas y Sistemas de Gestión de Información</div>
<div class="portada-datos">
<p><b>Alumno:</b> Miguel López Contreras</p>
<p><b>Profesor/a:</b> JESÚS</p>
<p><b>Aula:</b> Lenguaje de Marcas</p>
<p><b>Ciclo formativo:</b> 1º DAW · Desarrollo de Aplicaciones Web (CFGS)</p>
<p><b>Fecha de entrega:</b> </p>
<p><b>Curso académico:</b> 2026/27</p>
</div>
</div>

# Índice

```dataviewjs
// Índice automático: se rehace solo con cada # / ## / ### de esta nota. Enlaces [[#apartado]]: Better Export PDF los hace clicables en el PDF.
const ruta = dv.current().file.path;
const titulos = (app.metadataCache.getCache(ruta)?.headings ?? [])
  .filter((h) => h.level <= 3 && h.heading.trim().toLowerCase() !== 'índice');
const caja = dv.el('div', '', { cls: 'indice-auto' });
if (!titulos.length) dv.el('div', '_Escribe un título con `#` y aparecerá aquí._', { container: caja });
for (const h of titulos) dv.el('div', `[[#${h.heading}|${h.heading}]]`, { container: caja, cls: 'indice-n' + h.level });
```

> [!guia]- Índice y paginación (esta ayuda no sale en el PDF)
> - Los apartados son **los de los criterios de corrección**: si cambia uno, cambia también su título abajo.
> - Exporta a PDF con márgenes **Predeterminado** y sin «Incluir nombre del archivo como título» (la portada ya lo lleva): cada página sale numerada **X/Y**.
> - El índice se actualiza solo con cada `#` y `##` que escribas (con Dataview, sin plugins extra). Numera los apartados como en los criterios: `# 1. …`, `## 1.1 …`.

<div class="salto-pagina"></div>

# 1. Formulario de contacto con required y lista desplegable

```html
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Contacto</title>
</head>
<body>
  <h1>Formulario de contacto</h1>

  <form action="/enviar" method="post">
    <p>
      <label for="nombre">Nombre:</label>
      <input type="text" id="nombre" name="nombre" required>
    </p>

    <p>
      <label for="correo">Correo:</label>
      <input type="email" id="correo" name="correo" required>
    </p>
    <p>
      <label for="motivo">Motivo de contacto:</label>
      <select id="motivo" name="motivo" required>
        <option value="">-- Elige un motivo --</option>
        <option value="informacion">Solicitar información</option>
        <option value="incidencia">Comunicar una incidencia</option>
        <option value="sugerencia">Hacer una sugerencia</option>
      </select>
    </p>

    <p>
      <label for="mensaje">Mensaje:</label><br>
      <textarea id="mensaje" name="mensaje" rows="5" cols="40" required></textarea>
    </p>

    <button type="submit">Enviar</button>
  </form>
</body>
</html>
```

<div class="salto-pagina"></div>

<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Contacto</title>
</head>
<body>
  <h1>Formulario de contacto</h1>
  <form action="/enviar" method="post">
    <p>
      <label for="nombre">Nombre:</label>
      <input type="text" id="nombre" name="nombre" required>
    </p>
    <p>
      <label for="correo">Correo:</label>
      <input type="email" id="correo" name="correo" required>
    </p>
    <p>
      <label for="motivo">Motivo de contacto:</label>
      <select id="motivo" name="motivo" required>
        <option value="">-- Elige un motivo --</option>
        <option value="informacion">Solicitar información</option>
        <option value="incidencia">Comunicar una incidencia</option>
        <option value="sugerencia">Hacer una sugerencia</option>
      </select>
    </p>
    <p>
      <label for="mensaje">Mensaje:</label><br>
      <textarea id="mensaje" name="mensaje" rows="5" cols="40" required></textarea>
    </p>
    <button type="submit">Enviar</button>
  </form>
</body>
</html>


> [!check] Comprobación: enviar sin rellenar Al pulsar **Enviar** con los campos vacíos, el navegador **no envía el formulario**. Marca el primer campo vacío (Nombre) y muestra un aviso del tipo _«Completa este campo»_.
> 
> - Si escribes un correo sin `@`, el campo `email` avisa de que el formato no es válido.
> - La primera `<option>` tiene `value=""`, así que con `required` también obliga a elegir un motivo real.

<div class="salto-pagina"></div>

# 2. Unir la etiqueta y el campo

**Fragmento original:**


```html
<label for="email">Correo:</label><input type="email" name="email">
```

> [!bug] Qué falta El `<label>` tiene `for="email"`, pero el `<input>` **no tiene `id`**. El atributo `for` se relaciona con el **`id`** del campo, no con el `name`. Por eso el navegador no los relaciona.

**Solución:**

```html
<label for="email">Correo:</label>
<input type="email" id="email" name="email">
```

<label for="email">Correo:</label>
<input type="email" id="email" name="email">

> [!tip] Cómo comprobarlo Haz clic sobre el texto **«Correo:»**. Si están bien unidos, el cursor salta al campo. Esto también ayuda a los lectores de pantalla (accesibilidad).


<div class="salto-pagina"></div>

# 3. Predecir: escribir hola en un campo number

**Código:**


```html
<form>
  <input type="number" name="edad" required>
  <button type="submit">Enviar</button>
</form>
```

> [!question] Predicción **El formulario no se envía.** Un campo `type="number"` solo acepta números, así que `hola` no es un valor válido.
> 
> - **Chrome / Edge:** directamente **no deja escribir** las letras (solo admite dígitos y `e`, `+`, `-`, `.`). El campo queda vacío y, por el `required`, al enviar aparece _«Completa este campo»_.
> - **Firefox:** deja escribir `hola`, pero al enviar avisa con _«Introduce un número»_ y bloquea el envío.
> 
> En ambos casos el resultado es el mismo: **el navegador bloquea el envío y avisa al usuario.**

> [!check] Comprobación Pruébalo en tu navegador y anota aquí qué mensaje te sale:

<form>
  <input type="number" name="edad" required>
  <button type="submit">Enviar</button>
</form>


<div class="salto-pagina"></div>

# 4. Corregir el campo de correo y el botón

**Fragmento original:**

```html
<input type="text" name="correo" required><button>Enviar</button>
```

> [!bug] Errores
> 
> 1. `type="text"` no valida correos → debe ser **`type="email"`**.
> 2. El botón no indica qué hace → se le añade **`type="submit"`**.
> 3. No hay `<form>` que envuelva los elementos. Sin él, el botón **no tiene nada que enviar**.
> 4. _(Mejora)_ Falta un `<label>` unido al campo con `for` / `id`.

**Corrección:**


```html
<form action="/enviar" method="post">
  <label for="correo">Correo:</label>
  <input type="email" id="correo" name="correo" required>
  <button type="submit">Enviar</button>
</form>
```

<form action="/enviar" method="post">
  <label for="correo">Correo:</label>
  <input type="email" id="correo" name="correo" required>
  <button type="submit">Enviar</button>
</form>


<div class="salto-pagina"></div>
