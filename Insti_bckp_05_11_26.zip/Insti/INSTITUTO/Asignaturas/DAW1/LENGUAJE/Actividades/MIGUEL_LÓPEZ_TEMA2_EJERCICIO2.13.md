---
tags:
  - actividad
cssclasses:
  - trabajo
Asignatura: Lenguaje
Tema:
  - 02 - La web - HTML y CSS
Prioridad: Baja 🟢
To-Do: Realizado
Entrega:
Profesor: JESÚS
Aula: Lenguaje
---
<div class="portada">
<div class="portada-ciclo"><strong>CFGS Desarrollo de Aplicaciones Web</strong></div>
<div class="portada-titulo"><strong>MIGUEL_LÓPEZ_TEMA2_EJERCICIO2.13</strong></div>
<div class="portada-modulo"><strong>Lenguajes de Marcas y Sistemas de Gestión de Información</strong></div>
<div class="portada-datos">
<p><b>Alumno:</b> <strong>Miguel López Contreras</strong></p>
<br>
<p><b>Profesor/a:</b> <strong>JESÚS</strong></p>
<br>
<p><b>Aula:</b> <strong>Lenguaje</strong></p>
<br>
<p><b>Ciclo formativo:</b> <strong>1º DAW · Desarrollo de Aplicaciones Web (CFGS)</strong></p>
<br>
<p><b>Fecha de entrega:</b> </p>
<br>
<p><b>Curso académico:</b><strong> 2026/27</strong></p>
</div>
</div>

# Índice

```dataviewjs
// Índice automático: se rehace solo con cada # / ## / ### de esta nota. Enlaces [[#apartado]]: Better Export PDF los hace clicables en el PDF.
const ruta = dv.current().file.path;
const titulos = (app.metadataCache.getCache(ruta)?.headings ?? [])
  .filter((h) => h.level <= 3 && h.heading.trim().toLowerCase() !== 'índice');
const caja = dv.el('div', '', { cls: 'indice-auto' });
if (!titulos.length) dv.el('div', '_Escribe un título con `#` y aparecerá aquí._', { container: caja });
for (const h of titulos) dv.el('div', `[[#${h.heading}|${h.heading}]]`, { container: caja, cls: 'indice-n' + h.level });
```

> [!guia]- Índice y paginación (esta ayuda no sale en el PDF)
> - Los apartados son **los de los criterios de corrección**: si cambia uno, cambia también su título abajo.
> - Exporta a PDF con márgenes **Predeterminado** y sin «Incluir nombre del archivo como título» (la portada ya lo lleva): cada página sale numerada **X/Y**.
> - El índice se actualiza solo con cada `#` y `##` que escribas (con Dataview, sin plugins extra). Numera los apartados como en los criterios: `# 1. …`, `## 1.1 …`.

<div class="salto-pagina"></div>

# 1. Crea una tabla con tu horario

> [!tip] Ajusta las asignaturas y horas a tu horario real.
```html
<table border="1">
  <caption>Horario de clase · 1º DAW</caption>
  <thead>
    <tr>
      <th>Hora</th>
      <th>Lunes</th>
      <th>Martes</th>
      <th>Miércoles</th>
      <th>Jueves</th>
      <th>Viernes</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>15:00 - 16:00</td>
      <td>Programación</td>
      <td>Bases de Datos</td>
      <td>Lenguaje de Marcas</td>
      <td>Programación</td>
      <td>Sistemas Informáticos</td>
    </tr>
```

```html
    <tr>
      <td>16:00 - 17:00</td>
      <td>Programación</td>
      <td>Bases de Datos</td>
      <td>Lenguaje de Marcas</td>
      <td>Programación</td>
      <td>Sistemas Informáticos</td>
    </tr>
    <tr>
      <td>17:00 - 18:00</td>
      <td>Lenguaje de Marcas</td>
      <td>Entornos de Desarrollo</td>
      <td>Bases de Datos</td>
      <td>Sistemas Informáticos</td>
      <td>Entornos de Desarrollo</td>
    </tr>
    <tr>
      <td>18:30 - 19:30</td>
      <td>Sistemas Informáticos</td>
      <td>Programación</td>
      <td>Digitalización</td>
      <td>Bases de Datos</td>
      <td>Itinerario Empleabilidad</td>
    </tr>
    <tr>
      <td>19:30 - 20:30</td>
      <td>Itinerario Empleabilidad</td>
      <td>Programación</td>
      <td>Entornos de Desarrollo</td>
      <td>Lenguaje de Marcas</td>
      <td>Bases de Datos</td>
    </tr>
  </tbody>
</table>
```

<div class="salto-pagina"></div>

**Vista previa:**
<table border="1"> <caption>Horario de clase · 1º DAW</caption> <thead> <tr><th>Hora</th><th>Lunes</th><th>Martes</th><th>Miércoles</th><th>Jueves</th><th>Viernes</th></tr> </thead> <tbody> <tr><td>15:00 - 16:00</td><td>Programación</td><td>Bases de Datos</td><td>Lenguaje de Marcas</td><td>Programación</td><td>Sistemas Informáticos</td></tr> <tr><td>16:00 - 17:00</td><td>Programación</td><td>Bases de Datos</td><td>Lenguaje de Marcas</td><td>Programación</td><td>Sistemas Informáticos</td></tr> <tr><td>17:00 - 18:00</td><td>Lenguaje de Marcas</td><td>Entornos de Desarrollo</td><td>Bases de Datos</td><td>Sistemas Informáticos</td><td>Entornos de Desarrollo</td></tr> <tr><td>18:30 - 19:30</td><td>Sistemas Informáticos</td><td>Programación</td><td>Digitalización</td><td>Bases de Datos</td><td>Itinerario Empleabilidad</td></tr> <tr><td>19:30 - 20:30</td><td>Itinerario Empleabilidad</td><td>Programación</td><td>Entornos de Desarrollo</td><td>Lenguaje de Marcas</td><td>Bases de Datos</td></tr> </tbody> </table>

# 2. Completa esta tabla

**Enunciado:**

```html
<table>
  <caption>Precios</caption>
  <tr><th>Producto</th><th>Precio</th></tr>
  …
</table>
```

**Solución** (primera fila de datos + la segunda fila añadida con `<tr>` y `<td>`)

```html
<table border="1">
  <caption>Precios</caption>
  <tr>
    <th>Producto</th>
    <th>Precio</th>
  </tr>
  <tr>
    <td>Teclado</td>
    <td>25 €</td>
  </tr>
  <tr>
    <td>Ratón</td>
    <td>15 €</td>
  </tr>
</table>
```

**Vista previa:**
<table border="1"> <caption>Precios</caption> <tr><th>Producto</th><th>Precio</th></tr> <tr><td>Teclado</td><td>25 €</td></tr> <tr><td>Ratón</td><td>15 €</td></tr> </table>

# 3. Corrige los errores de este fragmento

**Fragmento original:**

```html
<table><td>Día</td><td>Hora</td><tr><td>Lunes</td></tr></table>
```

> [!bug] Errores encontrados
> 
> 1. Las celdas `Día` y `Hora` **no están dentro de un `<tr>`**. Toda celda (`<td>` o `<th>`) debe ir dentro de una fila.
> 2. `Día` y `Hora` son **encabezados**, así que deberían ser `<th>` y no `<td>`.
> 3. La segunda fila **solo tiene una celda** (`Lunes`) cuando la tabla tiene dos columnas: falta la celda de la hora.

**Corrección:**

```html
<table border="1">
  <tr>
    <th>Día</th>
    <th>Hora</th>
  </tr>
  <tr>
    <td>Lunes</td>
    <td>15:00</td>
  </tr>
</table>
```

**Vista previa:**

<table border="1"> <tr><th>Día</th><th>Hora</th></tr> <tr><td>Lunes</td><td>15:00</td></tr> </table>

# 4. Predice sin abrir el navegador

**Código:**

```html
<table>
  <tr><th>A</th><th>B</th><th>C</th></tr>
  <tr><td>1</td><td>2</td><td>3</td></tr>
</table>
```

> [!question] Predicción
> 
> - **Filas:** 2 → hay dos `<tr>`.
> - **Celdas:** 6 → 3 celdas de encabezado (`<th>`: A, B, C) + 3 celdas de datos (`<td>`: 1, 2, 3).
> - **Columnas:** 3 (cada fila tiene 3 celdas).
> 
> Al abrirlo en el navegador, la primera fila aparece en **negrita y centrada** (estilo por defecto de `<th>`) y la segunda en texto normal.

<div class="salto-pagina"></div>
**Comprobación (vista previa):**

<table border="1"> <tr><th>A</th><th>B</th><th>C</th></tr> <tr><td>1</td><td>2</td><td>3</td></tr> </table>

# 5. Escribe una tabla de tres filas


```html
<table border="1">
  <caption>Películas</caption>
  <tr>
    <th>Título</th>
    <th>Año</th>
  </tr>
  <tr>
    <td>El laberinto del fauno</td>
    <td>2006</td>
  </tr>
  <tr>
    <td>Interstellar</td>
    <td>2014</td>
  </tr>
</table>
```

**Vista previa:**

<table border="1"> <caption>Películas</caption> <tr><th>Título</th><th>Año</th></tr> <tr><td>El laberinto del fauno</td><td>2006</td></tr> <tr><td>Interstellar</td><td>2014</td></tr> </table>

---

> [!summary] Resumen
> 
> - Toda celda va **dentro de un `<tr>`**.
> - Usa `<th>` para encabezados y `<td>` para datos.
> - Todas las filas deben tener el **mismo número de celdas** (salvo que uses `colspan`/`rowspan`).
> 	- `<caption>` siempre va **justo después** de abrir `<table>`.

