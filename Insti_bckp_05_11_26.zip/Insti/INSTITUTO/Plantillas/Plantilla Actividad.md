<%*
/* ── Plantilla Actividad ─────────────────────────────────────────────
   Crea una entrega con: portada (título exacto, alumno, módulo, profesor,
   aula y ciclo, fecha/curso), índice con los apartados de los criterios
   de corrección y paginación X/Y al exportar a PDF (estilos en ui-componentes.css).
   ─────────────────────────────────────────────────────────────────── */
const NOMBRES = {'BADAT':'Base de Datos','PROGRAMACIÓN':'Programación','SISTEMAS':'Sistemas','ENTORNO':'Entorno','LENGUAJE':'Lenguaje','DIGITALIZACIÓN':'Digitalización','SOSTENIBILIDAD':'Sostenibilidad','IPE':'IPE'};
const MODULOS = {'BADAT':'Bases de Datos','PROGRAMACIÓN':'Programación','SISTEMAS':'Sistemas Informáticos','ENTORNO':'Entornos de Desarrollo','LENGUAJE':'Lenguajes de Marcas y Sistemas de Gestión de Información','DIGITALIZACIÓN':'Digitalización Aplicada a los Sectores Productivos','SOSTENIBILIDAD':'Sostenibilidad Aplicada al Sistema Productivo','IPE':'Itinerario Personal para la Empleabilidad I'};
const fmDe = (nombre) => { const f = tp.file.find_tfile(nombre); return (f && app.metadataCache.getFileCache(f)?.frontmatter) || {}; };
const limpio = (v) => (v ?? '').toString().trim();

// Asignatura: por la carpeta; si la nota está fuera de una asignatura, se pregunta.
let clave = tp.file.folder(true).split('/')[3];
if (!clave || !NOMBRES[clave]) clave = await tp.system.suggester(Object.values(NOMBRES), Object.keys(NOMBRES), false, '¿De qué asignatura es?') ?? '';
const asignatura = NOMBRES[clave] ?? clave;
const modulo = MODULOS[clave] ?? asignatura;

// Datos que ya están en la bóveda: alumno y curso (DAW HOME), profesor (nota de la asignatura).
const home = fmDe('DAW HOME');
const alumno = limpio(home.estudiante) || limpio(await tp.system.prompt('Nombre y apellidos del alumno', '', false));
const curso = limpio(home.curso) || '1º DAW · 2026/27';
const profesor = limpio(fmDe(clave).Profesor) || limpio(await tp.system.prompt('Nombre del profesor/a', '', false));

// Datos de esta entrega.
const titulo = limpio(await tp.system.prompt('Título EXACTO de la actividad (como lo pide el profesor)', tp.file.title.startsWith('Nueva') || tp.file.title.startsWith('Untitled') || tp.file.title.startsWith('Sin título') ? '' : tp.file.title, false)) || tp.file.title;
const tema = limpio(await tp.system.prompt('Tema (ej. 01 - Introducción)', '01 - ', false));
const entrega = limpio(await tp.system.prompt('Fecha de entrega (AAAA-MM-DD)', tp.date.now('YYYY-MM-DD', 7), false));
const aula = limpio(await tp.system.prompt('Aula', '', false));
const apartados = (await tp.system.prompt('Apartados de los criterios de corrección (separados por ;)', 'Introducción; Desarrollo; Conclusiones', false) ?? '')
  .split(';').map((s) => s.trim()).filter(Boolean);
if (!apartados.length) apartados.push('Desarrollo');

const fechaLarga = /^\d{4}-\d{2}-\d{2}$/.test(entrega) ? moment(entrega).locale('es').format('D [de] MMMM [de] YYYY') : entrega;
const q = (v) => JSON.stringify(v);   // valores YAML seguros (dos puntos, comillas…)

// El nombre de la nota pasa a ser el título exacto (sin caracteres que no admite un archivo).
const nombre = titulo.replace(/[\\/:*?"<>|#^\[\]]/g, '-').trim();
if (nombre && nombre !== tp.file.title) { try { await tp.file.rename(nombre); } catch (e) { new Notice('No se pudo renombrar: ya existe una nota con ese nombre.'); } }
-%>
---
tags:
  - actividad
cssclasses:
  - trabajo
Asignatura: <% asignatura %>
Tema:
  - <% q(tema) %>
Prioridad: Media 🟡
To-Do: Pendiente
Entrega: <% entrega %>
Profesor: <% q(profesor) %>
Aula: <% q(aula) %>
---
<div class="portada">
<div class="portada-ciclo">CFGS Desarrollo de Aplicaciones Web</div>
<div class="portada-titulo"><% titulo %></div>
<div class="portada-modulo"><% modulo %></div>
<div class="portada-datos">
<p><b>Alumno:</b> <% alumno %></p>
<p><b>Profesor/a:</b> <% profesor %></p>
<p><b>Aula:</b> <% aula || '—' %></p>
<p><b>Ciclo formativo:</b> <% curso.split('·')[0].trim() %> · Desarrollo de Aplicaciones Web (CFGS)</p>
<p><b>Fecha de entrega:</b> <% fechaLarga %></p>
<p><b>Curso académico:</b> <% (curso.split('·')[1] ?? '').trim() || curso %></p>
</div>
</div>

# Índice

```dataviewjs
// Índice automático: se rehace solo con cada # / ## / ### de esta nota. Enlaces [[#apartado]]: Better Export PDF los hace clicables en el PDF.
const ruta = dv.current().file.path;
const titulos = (app.metadataCache.getCache(ruta)?.headings ?? [])
  .filter((h) => h.level <= 3 && h.heading.trim().toLowerCase() !== 'índice');
const caja = dv.el('div', '', { cls: 'indice-auto' });
if (!titulos.length) dv.el('div', '_Escribe un título con `#` y aparecerá aquí._', { container: caja });
for (const h of titulos) dv.el('div', `[[#${h.heading}|${h.heading}]]`, { container: caja, cls: 'indice-n' + h.level });
```

> [!guia]- Índice y paginación (esta ayuda no sale en el PDF)
> - Los apartados son **los de los criterios de corrección**: si cambia uno, cambia también su título abajo.
> - Exporta a PDF con márgenes **Predeterminado** y sin «Incluir nombre del archivo como título» (la portada ya lo lleva): cada página sale numerada **X/Y**.
> - El índice se actualiza solo con cada `#` y `##` que escribas (con Dataview, sin plugins extra). Numera los apartados como en los criterios: `# 1. …`, `## 1.1 …`.

<div class="salto-pagina"></div>

<% apartados.map((a, i) => `# ${i + 1}. ${a}\n\n`).join('\n') %>



