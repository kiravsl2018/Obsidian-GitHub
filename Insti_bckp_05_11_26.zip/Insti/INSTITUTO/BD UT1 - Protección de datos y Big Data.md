---
asignatura: Bases de Datos
unidad: UT1 - El almacenamiento de la información
apartados: 1.9 y 1.10
tags:
  - temario
curso: 1º DAW · 2026/27
Aula: Bases de Datos
Tema:
  - Introducción
Asignatura: Base de Datos
---

# UT1 · 1.9 y 1.10 — Protección de datos y Big Data

> [!abstract] Lo más preguntable
> - Por qué la LOPDGDD es **orgánica** → protege un derecho fundamental → **mayoría absoluta**
> - Jerarquía: **RGPD > LOPDGDD > normativa autonómica**
> - Qué son los **datos sensibles**
> - **AEPD**: creada en **1992**, funciona desde **1994**, **independiente**
> - **4 agencias autonómicas**: Madrid, Cataluña, País Vasco y Andalucía
> - Los **4 roles** y la definición de **BI**
> - Las **5 V** del Big Data

---

## 1.9. Normativa vigente sobre protección de datos

Hay muchísimos datos nuestros en sistemas informáticos, y de ellos se puede sacar mucha información. Por eso las empresas deben usarlos y custodiarlos de forma responsable para proteger el **derecho a la intimidad**. Tanto los países como la **UE** tienen normativa reguladora de protección de datos.

### Derechos del ciudadano

| Derecho | Qué significa |
| --- | --- |
| **Acceso** | Preguntar al responsable si está tratando tus datos y, si es así, obtener información sobre ello |
| **Rectificación** | Pedir que corrijan datos inexactos o completen los incompletos, sin demora indebida |
| **Oposición** | Pedir que dejen de tratar tus datos por tu situación particular o por marketing directo |
| **Supresión** ("derecho al olvido") | Pedir que borren tus datos si ya no son necesarios, si retiras el consentimiento o si el tratamiento es ilegítimo |
| **Limitación del tratamiento** | Restringir el uso de tus datos aunque se sigan conservando |
| **Portabilidad** | Recibir tus datos en un formato estructurado y llevarlos a otro responsable |
| **No ser objeto de decisiones automatizadas** | No quedar sujeto a decisiones tomadas solo por máquinas que te afecten significativamente |

> [!note] Dónde acudo para ejercer mis derechos
> Las empresas deben informar de **qué datos guardan**, **con qué finalidad**, **durante cuánto tiempo** y **cómo ejercer los derechos**. Ejemplo de los apuntes: la política de privacidad de El Corte Inglés.

### Tipos de datos personales

- **Dato de carácter personal**: permite identificar a una persona (nombre, DNI, dirección postal, email…).
- **Datos sensibles**: están sujetos a condiciones de tratamiento específicas. Son los que revelan:
	- origen racial o étnico
	- opiniones políticas
	- convicciones religiosas o filosóficas
	- afiliación sindical
	- datos genéticos
	- datos biométricos (para identificar a una persona)
	- salud
	- vida sexual u orientación sexual

### La ley: LOPDGDD

**Ley Orgánica 3/2018, de 5 de diciembre**, de Protección de Datos Personales y garantía de los derechos digitales.

> [!important] ¿Por qué es una ley orgánica?
> Porque protege un **derecho fundamental** recogido en la **Constitución Española**. Toda ley que protege derechos constitucionales es orgánica y debe aprobarse por **mayoría absoluta**.

**Objetivo**: garantizar el derecho de todas las personas a la protección de sus datos, es decir, el derecho a la intimidad. Para ello establece bases, principios y procedimientos.

### Jerarquía normativa

1. **RGPD** (Reglamento europeo, 2016): marca los **mínimos** para toda la UE.
2. **LOPDGDD** (estatal): debe cumplir esos mínimos.
3. **Normativa autonómica**: puede concretar más, siempre que no se salte la LOPDGDD.

### AEPD — Agencia Española de Protección de Datos

Es quien **hace cumplir la LOPDGDD**.

- Se **creó en 1992** y **empezó a funcionar en 1994**.
- Es un **organismo público independiente**: actúa sin depender de los poderes públicos.
- **Función principal**: vigilar que se cumplan las normas de protección de datos y proteger los derechos y libertades de las personas en el uso de sus datos.
- Es la **"autoridad de control"** que exige el RGPD a cada Estado miembro.

### Agencias autonómicas

Hay **4** comunidades autónomas con agencia propia:

- Madrid
- Cataluña
- País Vasco
- Andalucía → **Consejo de Transparencia y Protección de Datos de Andalucía** (CTPDA)

### Roles y responsabilidades

| Rol | Quién es |
| --- | --- |
| **Interesado** | La persona dueña de los datos |
| **Responsable** | Decide **para qué y cómo** se tratan los datos |
| **Encargado** | Trata los datos **por cuenta del responsable** |
| **Delegado de Protección de Datos (DPD)** | Asesora y supervisa el cumplimiento. Es obligatorio en ciertos organismos y empresas |

---

## 1.10. Big Data e inteligencia de negocio

### ¿Qué es Big Data?

Es el manejo de **grandes cantidades de datos**, tanto **estructurados como no estructurados**, que las herramientas tradicionales no pueden procesar fácilmente.

Como hoy almacenar y analizar datos es más barato, las empresas usan el Big Data para **encontrar patrones**, **hacer predicciones** y **tomar mejores decisiones** basadas en datos.

### Las 5 V

| V | Significado |
| --- | --- |
| **Volumen** | Gran cantidad de datos que se generan y almacenan |
| **Velocidad** | Rapidez con la que los datos se crean, reciben y procesan |
| **Variedad** | Datos de distintos tipos: texto, imágenes… |
| **Veracidad** | Los datos deben ser fiables, precisos y de calidad |
| **Valor** | Los datos deben servir para mejorar decisiones, procesos o servicios |

### Evolución

- **Origen (años 60-70)**: primeros centros de datos y bases de datos.
- **Pasado (desde 2005)**: el auge de Internet dispara el volumen de datos y aparecen **Hadoop** y las BD **NoSQL**.
- **Presente**: sigue creciendo gracias a herramientas como **Hadoop** y **Spark**.
- **Futuro**: su valor seguirá creciendo gracias a la **IA generativa** y la **computación en la nube**.

### Ventajas

- Decisiones precisas y basadas en datos
- Detección de patrones y tendencias
- Predicción de comportamientos futuros
- Más eficiencia en procesos y servicios
- Mejor conocimiento de las necesidades de los clientes

### Herramientas de Big Data

> [!info] Según los apuntes, esta parte no entra en el examen
> Son programas y plataformas para almacenar, procesar, analizar y visualizar grandes cantidades de datos.

- **Hadoop**: almacena y procesa grandes volúmenes de datos.
- **Spark**: analiza datos muy rápido.
- **MongoDB**: base de datos para datos no estructurados.
- **Power BI** y **Tableau**: crean gráficos e informes para visualizar datos.

### BI — Business Intelligence (inteligencia de negocio)

Conjunto de **herramientas, procesos y métodos** para **recopilar, almacenar y analizar** los datos de una empresa u organismo. Su objetivo es obtener una **visión global** y **ayudar a tomar mejores decisiones**.

> [!tip] Relación Big Data ↔ BI
> Cuanto más crece el volumen de datos, más necesarias son las herramientas de **Big Data** dentro de la **BI**.
